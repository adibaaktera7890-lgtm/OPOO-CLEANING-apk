package com.teamily.oppocleaner.data

import android.content.Context
import android.content.pm.PackageManager
import com.teamily.oppocleaner.root.RootShell

/**
 * Lists installed apps and performs root-level removal / disable.
 *
 * Removal uses `pm uninstall --user 0 <pkg>`, which removes the app for the
 * current user only and keeps the APK on the system partition, so
 * `pm install-existing --user 0 <pkg>` can bring it back.
 */
object SystemAppRepository {

    /**
     * Packages that must never be removed: removing them breaks the phone
     * (no launcher, no settings, no telephony, boot loop).
     */
    private val protectedExact = setOf(
        "android",
        "com.android.systemui",
        "com.android.settings",
        "com.android.phone",
        "com.android.server.telecom",
        "com.android.providers.settings",
        "com.android.providers.media",
        "com.android.providers.contacts",
        "com.android.providers.telephony",
        "com.android.providers.downloads",
        "com.android.packageinstaller",
        "com.android.permissioncontroller",
        "com.google.android.packageinstaller",
        "com.google.android.permissioncontroller",
        "com.android.launcher3",
        "com.oppo.launcher",
        "com.coloros.launcher",
        "com.oplus.launcher",
        "com.android.keychain",
        "com.android.shell",
        "com.android.externalstorage",
        "com.android.mtp",
        "com.android.documentsui",
        "com.android.bluetooth",
        "com.android.nfc"
    )

    private val protectedPrefixes = listOf(
        "com.android.providers.",
        "com.android.internal.",
        "com.oplus.ota",
        "com.coloros.ota",
        "com.oppo.ota"
    )

    fun isProtected(packageName: String): Boolean =
        packageName in protectedExact || protectedPrefixes.any { packageName.startsWith(it) }

    /** Loads installed packages with APK size, enabled state and system flag. */
    suspend fun loadApps(context: Context, systemOnly: Boolean): List<SystemApp> {
        val listing = RootShell.run("pm list packages -f", timeoutSeconds = 120)
        if (!listing.ok) return emptyList()

        val entries = ArrayList<Pair<String, String>>() // apkPath to package
        listing.stdout.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (!line.startsWith("package:")) return@forEach
            val body = line.removePrefix("package:")
            val eq = body.lastIndexOf('=')
            if (eq <= 0) return@forEach
            val path = body.substring(0, eq)
            val pkg = body.substring(eq + 1)
            if (pkg.isNotEmpty()) entries.add(path to pkg)
        }
        if (entries.isEmpty()) return emptyList()

        val systemSet = RootShell.run("pm list packages -s", timeoutSeconds = 60)
            .stdout.lineSequence()
            .map { it.trim().removePrefix("package:") }
            .filter { it.isNotEmpty() }
            .toHashSet()

        val disabled = RootShell.run("pm list packages -d", timeoutSeconds = 30)
            .stdout.lineSequence()
            .map { it.trim().removePrefix("package:") }
            .filter { it.isNotEmpty() }
            .toHashSet()

        val filtered = if (systemOnly) entries.filter { it.second in systemSet } else entries
        if (filtered.isEmpty()) return emptyList()

        // One shell call measures every APK.
        val sizeScript = buildString {
            append("for f in")
            filtered.forEach { (path, _) ->
                append(" '").append(path.replace("'", "'\\''")).append("'")
            }
            appendLine("; do")
            appendLine("  printf '%s|%s\\n' \"\$f\" \"\$(stat -c %s \"\$f\" 2>/dev/null || echo 0)\"")
            appendLine("done")
        }
        val sizes = HashMap<String, Long>()
        RootShell.runScript(context, sizeScript, timeoutSeconds = 180).stdout.lineSequence().forEach { line ->
            val idx = line.lastIndexOf('|')
            if (idx > 0) {
                val path = line.substring(0, idx)
                val size = line.substring(idx + 1).trim().toLongOrNull() ?: 0L
                sizes[path] = size
            }
        }

        val pm = context.packageManager
        return filtered.map { (path, pkg) ->
            SystemApp(
                packageName = pkg,
                label = labelOf(pm, pkg),
                apkPath = path,
                sizeBytes = sizes[path] ?: 0L,
                enabled = pkg !in disabled,
                isSystem = pkg in systemSet,
                protected = isProtected(pkg)
            )
        }.sortedWith(compareBy({ !it.isSystem }, { it.label.lowercase() }))
    }

    private fun labelOf(pm: PackageManager, pkg: String): String = try {
        val info = pm.getApplicationInfo(pkg, 0)
        pm.getApplicationLabel(info).toString()
    } catch (_: Exception) {
        pkg
    }

    /** Removes the app for user 0. Returns (success, message). */
    suspend fun uninstall(pkg: String): Pair<Boolean, String> {
        val result = RootShell.run("pm uninstall --user 0 '$pkg'", timeoutSeconds = 90)
        val text = result.combined
        val success = result.ok && text.contains("Success", ignoreCase = true)
        return success to text
    }

    /** Disables the app for user 0. Returns (success, message). */
    suspend fun disable(pkg: String): Pair<Boolean, String> {
        val result = RootShell.run("pm disable-user --user 0 '$pkg'", timeoutSeconds = 60)
        val text = result.combined
        val success = result.ok && !text.contains("Error", ignoreCase = true)
        return success to text
    }

    /** Re-enables a disabled app. */
    suspend fun enable(pkg: String): Pair<Boolean, String> {
        val result = RootShell.run("pm enable --user 0 '$pkg'", timeoutSeconds = 60)
        val text = result.combined
        val success = result.ok && !text.contains("Error", ignoreCase = true)
        return success to text
    }

    /** Restores an app removed with `pm uninstall --user 0`. */
    suspend fun restore(pkg: String): Pair<Boolean, String> {
        val result = RootShell.run("pm install-existing --user 0 '$pkg'", timeoutSeconds = 90)
        val text = result.combined
        val success = result.ok && text.contains("installed", ignoreCase = true)
        return success to text
    }
}