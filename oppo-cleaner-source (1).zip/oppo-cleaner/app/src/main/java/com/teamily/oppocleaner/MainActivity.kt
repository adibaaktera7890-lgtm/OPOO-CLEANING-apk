package com.teamily.oppocleaner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.teamily.oppocleaner.data.JunkItem
import com.teamily.oppocleaner.data.RemovalAction
import com.teamily.oppocleaner.data.RemovedApp
import com.teamily.oppocleaner.data.RootState
import com.teamily.oppocleaner.data.SystemApp
import com.teamily.oppocleaner.ui.theme.Bg
import com.teamily.oppocleaner.ui.theme.Cyan
import com.teamily.oppocleaner.ui.theme.Danger
import com.teamily.oppocleaner.ui.theme.Good
import com.teamily.oppocleaner.ui.theme.OppoCleanerTheme
import com.teamily.oppocleaner.ui.theme.Surface1
import com.teamily.oppocleaner.ui.theme.Surface2
import com.teamily.oppocleaner.ui.theme.TextDim
import com.teamily.oppocleaner.ui.theme.TextMain
import com.teamily.oppocleaner.ui.theme.Warn

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            OppoCleanerTheme {
                Box(Modifier.fillMaxSize().background(Bg)) {
                    RootScreen()
                }
            }
        }
    }
}

private enum class Tab(val title: String) {
    JUNK("জাঙ্ক"),
    APPS("সিস্টেম অ্যাপ"),
    REMOVED("ফেরত")
}

@Composable
private fun RootScreen(vm: AppViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var tab by remember { mutableStateOf(Tab.JUNK) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(state.message) {
        val msg = state.message
        if (msg != null) {
            snackbar.showSnackbar(msg)
            vm.consumeMessage()
        }
    }

    Scaffold(
        containerColor = Bg,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar(containerColor = Surface1) {
                Tab.entries.forEach { entry ->
                    NavigationBarItem(
                        selected = tab == entry,
                        onClick = {
                            tab = entry
                            if (entry == Tab.APPS && state.apps.isEmpty()) vm.loadApps()
                        },
                        icon = {
                            Icon(
                                imageVector = when (entry) {
                                    Tab.JUNK -> Icons.Filled.Delete
                                    Tab.APPS -> Icons.Filled.Search
                                    Tab.REMOVED -> Icons.Filled.Refresh
                                },
                                contentDescription = entry.title
                            )
                        },
                        label = { Text(entry.title, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Header(state.root, onRetry = vm::checkRoot)

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (state.root) {
                    is RootState.Denied -> RootDeniedPanel(
                        reason = (state.root as RootState.Denied).reason,
                        onRetry = vm::checkRoot
                    )

                    else -> when (tab) {
                        Tab.JUNK -> JunkTab(state, vm)
                        Tab.APPS -> AppsTab(state, vm)
                        Tab.REMOVED -> RemovedTab(state, vm)
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(root: RootState, onRetry: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Oppo Cleaner", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("OPPO A6x · KernelSU", color = TextDim, fontSize = 12.sp)
        }
        RootBadge(root, onRetry)
    }
}

@Composable
private fun RootBadge(root: RootState, onRetry: () -> Unit) {
    val (color, label, icon) = when (root) {
        is RootState.Checking -> Triple(Warn, "রুট চেক…", Icons.Filled.Refresh)
        is RootState.Granted -> Triple(Good, "রুট আছে", Icons.Filled.CheckCircle)
        is RootState.Denied -> Triple(Danger, "রুট নেই", Icons.Filled.Error)
    }
    Row(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(color.copy(alpha = 0.14f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
            .clickable { onRetry() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun RootDeniedPanel(reason: String, onRetry: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Icon(Icons.Filled.Error, null, tint = Danger, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(16.dp))
        Text("রুট পারমিশন পাওয়া যায়নি", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(reason, color = TextDim, fontSize = 13.sp, lineHeight = 20.sp)
        Spacer(Modifier.height(16.dp))
        CardBox {
            Text("কী করবেন", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text(
                "১. KernelSU ম্যানেজার অ্যাপ খুলুন\n" +
                    "২. নিচের \"Superuser\" ট্যাবে যান\n" +
                    "৩. Oppo Cleaner খুঁজে অনুমতি দিন\n" +
                    "৪. এখানে ফিরে \"আবার চেষ্টা\" চাপুন",
                color = TextDim, fontSize = 12.sp, lineHeight = 19.sp
            )
        }
        Spacer(Modifier.height(16.dp))
        PrimaryButton("আবার চেষ্টা করুন", onRetry)
    }
}

@Composable
private fun JunkTab(state: UiState, vm: AppViewModel) {
    val total = state.junk.sumOf { it.sizeBytes }
    val selectedTotal = state.junk.filter { it.target.id in state.selectedJunk }.sumOf { it.sizeBytes }

    Column(Modifier.fillMaxSize()) {
        CardBox(Modifier.padding(horizontal = 16.dp)) {
            Text("মোট জাঙ্ক", color = TextDim, fontSize = 12.sp)
            Text(formatBytes(total), color = Cyan, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                if (state.junk.isEmpty()) "স্ক্যান করতে নিচের বাটন চাপুন"
                else "নির্বাচিত: ${formatBytes(selectedTotal)}",
                color = TextDim, fontSize = 12.sp
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryButton(
                    if (state.scanning) "স্ক্যান হচ্ছে…" else "স্ক্যান করুন",
                    onClick = vm::scanJunk,
                    enabled = !state.scanning && !state.busy,
                    modifier = Modifier.weight(1f)
                )
                PrimaryButton(
                    "ডিলিট (${state.selectedJunk.size})",
                    onClick = vm::deleteSelectedJunk,
                    enabled = state.selectedJunk.isNotEmpty() && !state.busy && !state.scanning,
                    danger = true,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        if (state.scanning) {
            Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Cyan)
            }
        } else {
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp)
            ) {
                items(state.junk, key = { it.target.id }) { item ->
                    JunkRow(
                        item = item,
                        checked = item.target.id in state.selectedJunk,
                        onToggle = { vm.toggleJunk(item.target.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun JunkRow(item: JunkItem, checked: Boolean, onToggle: () -> Unit) {
    val empty = item.sizeBytes <= 0L
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Surface1)
            .clickable(enabled = !empty) { onToggle() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CheckBox(checked = checked && !empty, enabled = !empty, onToggle = onToggle)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(item.target.label, color = if (empty) TextDim else TextMain, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                if (item.target.risky) {
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Filled.Warning, null, tint = Warn, modifier = Modifier.size(13.dp))
                }
            }
            Text(item.target.description, color = TextDim, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        Text(
            if (empty) "—" else formatBytes(item.sizeBytes),
            color = if (empty) TextDim else Cyan,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun AppsTab(state: UiState, vm: AppViewModel) {
    var pending by remember { mutableStateOf<Pair<SystemApp, RemovalAction>?>(null) }

    val filtered = remember(state.apps, state.appQuery) {
        val q = state.appQuery.trim().lowercase()
        if (q.isEmpty()) state.apps
        else state.apps.filter {
            it.label.lowercase().contains(q) || it.packageName.lowercase().contains(q)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp)) {
            OutlinedTextField(
                value = state.appQuery,
                onValueChange = vm::setAppQuery,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("নাম বা প্যাকেজ খুঁজুন", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Filled.Search, null, tint = TextDim) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("শুধু সিস্টেম অ্যাপ", color = TextDim, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Switch(
                    checked = state.systemOnly,
                    onCheckedChange = vm::setSystemOnly,
                    enabled = !state.loadingApps
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${filtered.size}টি অ্যাপ", color = TextDim, fontSize = 12.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = vm::loadApps, enabled = !state.loadingApps) {
                    Text(if (state.loadingApps) "লোড হচ্ছে…" else "রিফ্রেশ", color = Cyan, fontSize = 12.sp)
                }
            }
        }

        if (state.loadingApps) {
            Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Cyan)
            }
        } else {
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 16.dp)
            ) {
                items(filtered, key = { it.packageName }) { app ->
                    AppRow(
                        app = app,
                        onUninstall = { pending = app to RemovalAction.UNINSTALL },
                        onDisable = { pending = app to RemovalAction.DISABLE }
                    )
                }
            }
        }
    }

    pending?.let { (app, action) ->
        ConfirmRemovalDialog(
            app = app,
            action = action,
            onDismiss = { pending = null },
            onConfirm = {
                pending = null
                vm.removeApp(app, action)
            }
        )
    }
}

@Composable
private fun AppRow(app: SystemApp, onUninstall: () -> Unit, onDisable: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Surface1)
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        app.label,
                        color = TextMain,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (app.isSystem) {
                        Spacer(Modifier.width(6.dp))
                        Tag("সিস্টেম", Cyan)
                    }
                    if (!app.enabled) {
                        Spacer(Modifier.width(4.dp))
                        Tag("বন্ধ", Warn)
                    }
                    if (app.protected) {
                        Spacer(Modifier.width(4.dp))
                        Tag("সুরক্ষিত", Danger)
                    }
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    app.packageName,
                    color = TextDim,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(formatBytes(app.sizeBytes), color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }

        if (!app.protected) {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton("ডিজেবল", Warn, onDisable, Modifier.weight(1f))
                SmallButton("আনইনস্টল", Danger, onUninstall, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ConfirmRemovalDialog(
    app: SystemApp,
    action: RemovalAction,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    val isUninstall = action == RemovalAction.UNINSTALL
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface2,
        titleContentColor = TextMain,
        textContentColor = TextDim,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Warning, null, tint = Danger, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (isUninstall) "আনইনস্টল করবেন?" else "ডিজেবল করবেন?", fontSize = 16.sp)
            }
        },
        text = {
            Column {
                Text(app.label, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(app.packageName, color = TextDim, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Text(
                    if (isUninstall)
                        "এই অ্যাপটি আপনার ইউজার থেকে সরানো হবে। APK সিস্টেম পার্টিশনে থাকবে, তাই \"ফেরত\" ট্যাব থেকে আবার ইনস্টল করা যাবে।"
                    else
                        "অ্যাপটি নিষ্ক্রিয় হবে, কিন্তু মুছে যাবে না। \"ফেরত\" ট্যাব থেকে আবার চালু করা যাবে।",
                    color = TextDim, fontSize = 12.sp, lineHeight = 18.sp
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    "⚠ ফোনের মূল অ্যাপ (launcher, settings, phone) মুছলে ফোন বুট নাও হতে পারে।",
                    color = Warn, fontSize = 11.sp, lineHeight = 16.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(if (isUninstall) "হ্যাঁ, আনইনস্টল" else "হ্যাঁ, ডিজেবল", color = Danger, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল", color = TextDim) }
        }
    )
}

@Composable
private fun RemovedTab(state: UiState, vm: AppViewModel) {
    if (state.removed.isEmpty()) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Filled.CheckCircle, null, tint = TextDim, modifier = Modifier.size(44.dp))
            Spacer(Modifier.height(12.dp))
            Text("কিছু সরানো হয়নি", color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Text(
                "সিস্টেম অ্যাপ ট্যাব থেকে যা সরাবেন, তার তালিকা এখানে থাকবে — এক চাপে ফিরিয়ে আনা যাবে।",
                color = TextDim, fontSize = 12.sp, lineHeight = 18.sp
            )
        }
        return
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp)
    ) {
        items(state.removed, key = { it.packageName }) { item ->
            RemovedRow(item, onRestore = { vm.restoreApp(item) }, enabled = !state.busy)
        }
    }
}

@Composable
private fun RemovedRow(item: RemovedApp, onRestore: () -> Unit, enabled: Boolean) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Surface1)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(item.label, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(item.packageName, color = TextDim, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(3.dp))
            Tag(if (item.action == RemovalAction.UNINSTALL) "আনইনস্টল করা" else "ডিজেবল করা", Warn)
        }
        Spacer(Modifier.width(8.dp))
        SmallButton("ফিরিয়ে আনুন", Good, onRestore, Modifier.width(110.dp), enabled = enabled)
    }
}

// ---------- small shared pieces ----------

@Composable
private fun CardBox(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Surface1)
            .padding(14.dp)
    ) { content() }
}

@Composable
private fun Tag(text: String, color: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.16f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(text, color = color, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun CheckBox(checked: Boolean, enabled: Boolean, onToggle: () -> Unit) {
    val color = when {
        !enabled -> TextDim.copy(alpha = 0.4f)
        checked -> Cyan
        else -> TextDim
    }
    Box(
        Modifier
            .size(20.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (checked && enabled) Cyan.copy(alpha = 0.18f) else Color.Transparent)
            .border(1.5.dp, color, RoundedCornerShape(6.dp))
            .clickable(enabled = enabled) { onToggle() },
        contentAlignment = Alignment.Center
    ) {
        if (checked && enabled) {
            Icon(Icons.Filled.CheckCircle, null, tint = Cyan, modifier = Modifier.size(14.dp))
        }
    }
}

@Composable
private fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
    danger: Boolean = false,
    modifier: Modifier = Modifier
) {
    val base = if (danger) Danger else Cyan
    val bg = if (enabled) base else Surface2
    val fg = if (enabled) Color(0xFF04222B) else TextDim
    Box(
        modifier
            .height(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = fg, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SmallButton(
    text: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Box(
        modifier
            .height(34.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(color.copy(alpha = if (enabled) 0.16f else 0.06f))
            .border(1.dp, color.copy(alpha = if (enabled) 0.45f else 0.15f), RoundedCornerShape(9.dp))
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) color else TextDim, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}
