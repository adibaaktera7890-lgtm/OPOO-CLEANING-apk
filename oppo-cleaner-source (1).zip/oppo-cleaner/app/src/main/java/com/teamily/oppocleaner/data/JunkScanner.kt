package com.teamily.oppocleaner.data

import android.content.Context
import com.teamily.oppocleaner.root.RootShell

/**
 * Measures and deletes well-known cache / junk locations.
 *
 * Only cache and log locations are touched. App data directories
 * (/data/data/<pkg>/databases, shared_prefs, files) are never deleted.
 */
object JunkScanner {

    val targets: List<JunkTarget> = listOf(
        JunkTarget(
            id = "app_cache",
            label = "অ্যাপ ক্যাশ",
            description = "সব ইনস্টল করা অ্যাপের cache ফোল্ডার",
            scanGlob = "/data/data/*/cache",
            deleteCommand = "rm -rf /data/data/*/cache/* 2>/dev/null"
        ),
        JunkTarget(
            id = "app_code_cache",
            label = "অ্যাপ কোড ক্যাশ",
            description = "compiled code cache — নিরাপদে আবার তৈরি হয়",
            scanGlob = "/data/data/*/code_cache",
            deleteCommand = "rm -rf /data/data/*/code_cache/* 2>/dev/null"
        ),
        JunkTarget(
            id = "sdcard_app_cache",
            label = "SD কার্ড অ্যাপ ক্যাশ",
            description = "/sdcard/Android/data/*/cache",
            scanGlob = "/sdcard/Android/data/*/cache",
            deleteCommand = "rm -rf /sdcard/Android/data/*/cache/* 2>/dev/null"
        ),
        JunkTarget(
            id = "thumbnails",
            label = "থাম্বনেইল",
            description = "গ্যালারির পুরোনো thumbnail ক্যাশ",
            scanGlob = "/sdcard/DCIM/.thumbnails",
            deleteCommand = "rm -rf /sdcard/DCIM/.thumbnails/* 2>/dev/null"
        ),
        JunkTarget(
            id = "log",
            label = "সিস্টেম লগ",
            description = "/data/log — ColorOS এর লগ ফাইল",
            scanGlob = "/data/log",
            deleteCommand = "rm -rf /data/log/* 2>/dev/null"
        ),
        JunkTarget(
            id = "anr",
            label = "ANR ট্রেস",
            description = "অ্যাপ হ্যাং হওয়ার ডাম্প ফাইল",
            scanGlob = "/data/anr",
            deleteCommand = "rm -rf /data/anr/* 2>/dev/null"
        ),
        JunkTarget(
            id = "tombstones",
            label = "ক্র্যাশ ডাম্প",
            description = "/data/tombstones — নেটিভ ক্র্যাশ লগ",
            scanGlob = "/data/tombstones",
            deleteCommand = "rm -rf /data/tombstones/* 2>/dev/null"
        ),
        JunkTarget(
            id = "dropbox",
            label = "সিস্টেম ড্রপবক্স",
            description = "/data/system/dropbox — সিস্টেম ইভেন্ট লগ",
            scanGlob = "/data/system/dropbox",
            deleteCommand = "rm -rf /data/system/dropbox/* 2>/dev/null"
        ),
        JunkTarget(
            id = "tmp",
            label = "টেম্প ফাইল",
            description = "/data/local/tmp — অস্থায়ী ফাইল",
            scanGlob = "/data/local/tmp",
            deleteCommand = "rm -rf /data/local/tmp/* 2>/dev/null"
        ),
        JunkTarget(
            id = "lost_dir",
            label = "LOST.DIR",
            description = "ফাইল সিস্টেমের হারানো টুকরো",
            scanGlob = "/sdcard/LOST.DIR",
            deleteCommand = "rm -rf /sdcard/LOST.DIR/* 2>/dev/null"
        ),
        JunkTarget(
            id = "dalvik_cache",
            label = "Dalvik/ART ক্যাশ",
            description = "আবার তৈরি হবে — প্রথম বুট একটু ধীর হতে পারে",
            scanGlob = "/data/dalvik-cache",
            deleteCommand = "rm -rf /data/dalvik-cache/* 2>/dev/null",
            risky = true
        )
    )

    /** Measures every target in one root shell call. */
    suspend fun scan(context: Context): List<JunkItem> {
        val script = buildString {
            appendLine("sz() {")
            appendLine("  t=0")
            appendLine("  for f in \$1; do")
            appendLine("    [ -e \"\$f\" ] || continue")
            appendLine("    v=\$(du -sk \"\$f\" 2>/dev/null | awk '{print \$1}')")
            appendLine("    [ -n \"\$v\" ] && t=\$((t+v))")
            appendLine("  done")
            appendLine("  echo \$t")
            appendLine("}")
            targets.forEach { target ->
                appendLine("echo \"${target.id}|\$(sz '${target.scanGlob}')\"")
            }
        }

        val result = RootShell.runScript(context, script, timeoutSeconds = 150)
        val sizes = HashMap<String, Long>()
        result.stdout.lineSequence().forEach { line ->
            val parts = line.trim().split('|')
            if (parts.size == 2) {
                val kb = parts[1].trim().toLongOrNull() ?: 0L
                sizes[parts[0]] = kb * 1024L
            }
        }

        return targets.map { target ->
            JunkItem(target = target, sizeBytes = sizes[target.id] ?: 0L)
        }
    }

    /** Deletes the given targets. Returns (succeededCount, output). */
    suspend fun delete(context: Context, items: List<JunkItem>): Pair<Int, String> {
        if (items.isEmpty()) return 0 to ""
        val script = items.joinToString("\n") { it.target.deleteCommand }
        val result = RootShell.runScript(context, script, timeoutSeconds = 240)
        return (if (result.ok) items.size else 0) to result.combined
    }
}
