package com.teamily.oppocleaner.data

/** One scannable junk location. */
data class JunkTarget(
    val id: String,
    val label: String,
    val description: String,
    /** Shell glob used for measuring, e.g. /data/data/*/cache */
    val scanGlob: String,
    /** Shell command that removes it. */
    val deleteCommand: String,
    /** Risky targets are unchecked by default and show a stronger warning. */
    val risky: Boolean = false
)

/** A junk target with its measured size. */
data class JunkItem(
    val target: JunkTarget,
    val sizeBytes: Long
)

/** An installed app. */
data class SystemApp(
    val packageName: String,
    val label: String,
    val apkPath: String,
    val sizeBytes: Long,
    val enabled: Boolean,
    val isSystem: Boolean,
    val protected: Boolean
)

enum class RemovalAction { UNINSTALL, DISABLE }

/** An app this tool removed, kept so it can be restored. */
data class RemovedApp(
    val packageName: String,
    val label: String,
    val action: RemovalAction,
    val timestamp: Long
)

sealed interface RootState {
    data object Checking : RootState
    data class Granted(val version: String?) : RootState
    data class Denied(val reason: String) : RootState
}
