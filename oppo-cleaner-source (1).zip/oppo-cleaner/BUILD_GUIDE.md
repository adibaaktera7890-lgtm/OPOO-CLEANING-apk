# Oppo Cleaner — ফোনে অ্যাপটি বসানোর গাইড

এটি **Oppo Cleaner** অ্যাপের সম্পূর্ণ সোর্স কোড (Kotlin + Jetpack Compose, প্যাকেজ আইডি `com.teamily.oppocleaner`)।

> **এই স্যান্ডবক্সে APK বিল্ড করা হয় না।** Android অ্যাপ বিল্ড ও সাইন করতে হয়, আর এখানে ফোন নেই যাতে টেস্ট করা যায় — তাই APK বানানো ব্লক করা। কিন্তু আপনার নিজের কম্পিউটারে **Android Studio ইনস্টল করার দরকার নেই** — নিচের **পথ ১** দেখুন, GitHub-এর নিজের সার্ভারে এক ক্লিকে APK বানিয়ে নিতে পারবেন।

---

## অ্যাপটি কী করে

| ট্যাব | কাজ |
|---|---|
| **জাঙ্ক** | ১১টি ক্যাশ/লগ লোকেশন স্ক্যান করে কত জায়গা নিচ্ছে দেখায়, বেছে বেছে ডিলিট করে |
| **সিস্টেম অ্যাপ** | ইনস্টল করা অ্যাপের নাম, প্যাকেজ, APK সাইজ, সিস্টেম কিনা — সব দেখায়; ডিজেবল/আনইনস্টল করে |
| **ফেরত** | যা সরানো হয়েছে তার তালিকা; এক চাপে ফিরিয়ে আনে |

রুট পারমিশন না থাকলে অ্যাপ স্পষ্টভাবে জানায় এবং কী করতে হবে তা দেখায়।

---

# পথ ১ — Android Studio ছাড়া (সবচেয়ে সহজ) ⭐

এই পথে APK বানায় **GitHub-এর নিজের কম্পিউটার** — আপনার মেশিনে কিছু ইনস্টল করতে হবে না। শুধু লাগবে একটা ফ্রি GitHub অ্যাকাউন্ট আর একটা ব্রাউজার।

## ১. GitHub-এ একটা নতুন রিপোজিটরি বানান

1. https://github.com/new খুলুন
2. নাম দিন যেমন `oppo-cleaner`, **Private** রাখতে পারেন
3. **Create repository** চাপুন

## ২. সোর্স আপলোড করুন

**সবচেয়ে সহজ — ব্রাউজার দিয়েই:**

1. নতুন রিপোর পেজে **Add file → Upload files** চাপুন
2. `oppo-cleaner-source.zip` ফাইলটা আগে আনজিপ করুন
3. আনজিপ করা ফোল্ডারের **ভেতরের সব ফাইল/ফোল্ডার** (app, gradle, build.gradle.kts, settings.gradle.kts, gradlew, `.github` — সব) সিলেক্ট করে ড্র্যাগ করে আপলোড বক্সে ছাড়ুন
   - ⚠️ `.github` ফোল্ডারটা অবশ্যই যাবে — এতেই বিল্ড স্ক্রিপ্ট আছে। হিডেন ফোল্ডার দেখতে ফাইল ম্যানেজারে "show hidden files" চালু করুন
4. নিচে **Commit changes** চাপুন

**অথবা Git জানা থাকলে টার্মিনাল দিয়ে:**

```bash
unzip oppo-cleaner-source.zip
cd oppo-cleaner
git init
git add .
git commit -m "Oppo Cleaner"
git branch -M main
git remote add origin https://github.com/<আপনার-ইউজারনেম>/oppo-cleaner.git
git push -u origin main
```

## ৩. বিল্ড চলতে শুরু করবে

- পুশ বা Commit করার সাথে সাথেই বিল্ড নিজে থেকে শুরু হবে
- অথবা রিপোর **Actions** ট্যাব → বাঁয়ে **Build Debug APK** → ডানে **Run workflow** → **Run workflow** চাপুন
- ২–৫ মিনিট অপেক্ষা করুন (পেজ রিফ্রেশ করুন)

## ৪. APK নামান

1. **Actions** ট্যাব খুলুন
2. সবুজ টিক ✅ ওয়ালা সবচেয়ে উপরের রানটায় ক্লিক করুন
3. নিচে **Artifacts** সেকশনে **oppo-cleaner-debug-apk** দেখবেন — ক্লিক করলে একটা zip নামবে
4. zip-টা আনজিপ করলে ভেতরে **`app-debug.apk`** পাবেন — এটাই আপনার ইনস্টলযোগ্য অ্যাপ

---

# পথ ২ — Android Studio দিয়ে

**যা লাগবে:** Android Studio — https://developer.android.com/studio থেকে ডাউনলোড করুন। এর সাথে JDK 17 আর Android SDK 35 নিজে থেকেই আসে।

1. `oppo-cleaner-source.zip` আনজিপ করুন
2. Android Studio → **File → Open** → আনজিপ করা `oppo-cleaner` ফোল্ডার
3. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন (প্রথমবার ২–৫ মিনিট, ইন্টারনেট লাগবে)
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. নিচে ডানদিকে notification আসবে → **locate** ক্লিক করুন
6. ফাইল: `app/build/outputs/apk/debug/app-debug.apk`

**কমান্ড লাইন দিয়ে (বিকল্প):**

```bash
cd oppo-cleaner
chmod +x gradlew
./gradlew assembleDebug
```

Windows-এ:

```bat
cd oppo-cleaner
gradlew.bat assembleDebug
```

ফলাফল: `app/build/outputs/apk/debug/app-debug.apk`

---

# ধাপ — ফোনে ইনস্টল করুন

1. `app-debug.apk` ফাইলটি ফোনে কপি করুন (USB, Google Drive, বা Telegram — যেভাবে সুবিধা)
2. ফোনে ফাইলটি খুলুন
3. Android জিজ্ঞেস করবে "unknown apps" অনুমতি — **Settings → Allow from this source** দিন
4. **Install** চাপুন

অথবা ADB দিয়ে:

```bash
adb install -r app-debug.apk
```

# ধাপ — রুট অনুমতি দিন

1. অ্যাপ খুলুন
2. উপরে ডানদিকে **"রুট নেই"** দেখাবে এবং KernelSU একটি পপআপ দেবে
3. **Allow** চাপুন (স্থায়ীভাবে দিতে চাইলে "Remember" টিক দিন)
4. অ্যাপে ফিরে **"আবার চেষ্টা করুন"** চাপুন → এখন **"রুট আছে"** দেখাবে

KernelSU ম্যানেজার থেকে হাতে দেওয়ার নিয়ম: **Superuser** ট্যাব → **Oppo Cleaner** → অনুমতি চালু।

---

## ⚠️ সাবধানতা — পড়ে নিন

**যা কখনো মুছবেন না** (অ্যাপ নিজেই এগুলো লক করে রেখেছে, তবু জেনে রাখুন):

- Launcher (`com.oppo.launcher`, `com.coloros.launcher`, `com.android.launcher3`)
- Settings (`com.android.settings`)
- SystemUI (`com.android.systemui`)
- Phone / Telecom (`com.android.phone`, `com.android.server.telecom`)
- সব `com.android.providers.*` (contacts, media, telephony, settings)
- OTA আপডেট (`com.oplus.ota`, `com.coloros.ota`)

এগুলোর কোনোটা মুছলে ফোন বুট নাও হতে পারে বা কল/ইন্টারনেট বন্ধ হয়ে যেতে পারে।

**নিরাপদে সরানো যায়** (সাধারণত): Facebook, Chrome, YouTube, Google Photos, Netflix, Amazon, Spotify, বিল্ট-ইন গেম, OPPO-র অতিরিক্ত অ্যাপ (Theme Store, Game Center, Browser)।

**পরামর্শ:** প্রথমে **ডিজেবল** করুন, কয়েকদিন ব্যবহার করে দেখুন সব ঠিক আছে। সমস্যা হলে **ফেরত** ট্যাব থেকে চালু করে দিন। সব ঠিক থাকলে তারপর আনইনস্টল করুন।

**আনইনস্টল আসলে কী করে:** `pm uninstall --user 0` ব্যবহার করে — অর্থাৎ আপনার ইউজার থেকে সরায়, কিন্তু APK সিস্টেম পার্টিশনে থেকে যায়। তাই **ফেরত** ট্যাব থেকে `pm install-existing` দিয়ে ফিরিয়ে আনা যায়। ফ্যাক্টরি রিসেট করলেও সব ফিরে আসবে।

**জাঙ্ক ডিলিট সম্পর্কে:** শুধু cache, code_cache, log, ANR, tombstone, dropbox, tmp, thumbnail, LOST.DIR মুছে। অ্যাপের databases, shared_prefs বা files কখনো ছোঁয় না। "Dalvik/ART ক্যাশ" ডিফল্টে আনচেক থাকে — ওটা মুছলে পরের বুট একটু ধীর হবে।

---

## যা যাচাই করা হয়েছে, আর যা হয়নি

**যাচাই করা হয়েছে:** সব Kotlin ফাইলের সিনট্যাক্স ও ব্র্যাকেট ভারসাম্য, Gradle কনফিগ, ম্যানিফেস্ট, রিসোর্স — হাতে রিভিউ করে মিলিয়ে দেখা হয়েছে। GitHub Actions ওয়ার্কফ্লোর YAML সিনট্যাক্স যাচাই করা হয়েছে।

**যাচাই করা হয়নি:** এখানে Android SDK নেই (স্যান্ডবক্স বিল্ড ব্লক করে), তাই কোড **কম্পাইল করা হয়নি** এবং **ফোনে চালানো হয়নি**। প্রথম বিল্ডে কোনো এরর এলে সেটার টেক্সট বা স্ক্রিনশট পাঠান — ঠিক করে দেব।

---

## ফাইল স্ট্রাকচার

```
oppo-cleaner/
├── .github/workflows/build-apk.yml   ← ক্লাউড বিল্ড (পথ ১)
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradlew / gradlew.bat
├── gradle/wrapper/
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/values/{strings,themes}.xml
        ├── res/drawable/ic_launcher.xml
        └── java/com/teamily/oppocleaner/
            ├── MainActivity.kt        (UI — ৩টি ট্যাব)
            ├── AppViewModel.kt        (স্টেট ও লজিক)
            ├── root/RootShell.kt      (su দিয়ে কমান্ড)
            ├── data/Models.kt
            ├── data/JunkScanner.kt    (ক্যাশ স্ক্যান/ডিলিট)
            ├── data/SystemAppRepository.kt (অ্যাপ লিস্ট/আনইনস্টল)
            ├── data/RemovedAppsStore.kt    (ফেরত তালিকা)
            └── ui/theme/Theme.kt
```
